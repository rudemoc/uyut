const fs = require('fs');
const path = require('path');
const use = require('@tensorflow-models/universal-sentence-encoder');
const tf = require('@tensorflow/tfjs'); // обязательно tfjs-node
const cliProgress = require('cli-progress');

async function run() {
  console.log('🔄 Загружаем модель USE...');
  const model = await use.load();

  const corpusPath = path.join(__dirname, 'corpus/training.txt');
  const lines = fs.readFileSync(corpusPath, 'utf-8')
    .split('\n')
    .map(l => l.trim())
    .filter(l => l.length > 0);

  const bar = new cliProgress.SingleBar({
    format: 'Обработка |{bar}| {percentage}% | {value}/{total} строк',
    barCompleteChar: '\u2588',
    barIncompleteChar: '\u2591',
    hideCursor: true
  });

  const embeddings = [];
  bar.start(lines.length, 0);

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    try {
      const emb = await model.embed([line]);              // Асинхронно получаем эмбеддинг
      const vector = emb.arraySync()[0];                  // Синхронно получаем данные
      embeddings.push({ text: line, vector });
      emb.dispose();                                      // Очищаем вручную
      bar.update(i + 1);
    } catch (err) {
      console.error(`⚠️ Ошибка на строке ${i}: ${err.message}`);
    }
  }

  bar.stop();

  fs.writeFileSync('embeddings.json', JSON.stringify(embeddings, null, 2));
  console.log("✅ Embeddings сохранены в embeddings.json");

  // Освобождение всех переменных
  tf.disposeVariables();
}

run().catch(err => {
  console.error("❌ Ошибка при выполнении:", err);
});
