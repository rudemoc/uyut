const fs = require('fs');
const readline = require('readline');
const path = require('path');
const tf = require('@tensorflow/tfjs');
const use = require('@tensorflow-models/universal-sentence-encoder');
const yargs = require('yargs');
const { hideBin } = require('yargs/helpers');

const argv = yargs(hideBin(process.argv))
  .option('threshold', {
    alias: 't',
    type: 'number',
    default: 0.75,
    describe: 'Минимальная косинусная схожесть для использования retrieval'
  })
  .option('topk', {
    alias: 'k',
    type: 'number',
    default: 3,
    describe: 'Количество вариантов для топ-k сэмплинга'
  })
  .help()
  .alias('help', 'h')
  .argv;

let markov = {};
let texts = [];
let embeddingTensor;
let embeddingNorms;
let model;
// Заменяем lastResponse на очередь ожидающих оценки ответов
let pendingResponses = [];
let ratings = {};

const historyPath = path.join(__dirname, 'history.txt');

function saveToHistory(role, text) {
  fs.appendFileSync(historyPath, `${new Date().toISOString()} ${role}: ${text}\n`);
}

function selectSentences(text) {
  const sentences = text.match(/[^.!?]+[.!?]+/g) || [text];
  const maxSentences = Math.min(sentences.length, 3);
  const n = Math.floor(Math.random() * maxSentences) + 1;
  return sentences.slice(0, n).join(' ').trim();
}

// Новая версия функции: вместо исключения rating===1, используем разные множители
function cosineWeights(similarity, rating) {
  let multiplier;
  switch (rating) {
    case 1:
      multiplier = 0.8; break; // пониженный множитель для ответа с рейтингом 1
    case 2:
      multiplier = 1.0; break;
    case 3:
      multiplier = 1.2; break;
    case 4:
      multiplier = 1.5; break;
    case 5:
      multiplier = 2.0; break;
    default:
      multiplier = 1.0; break;
  }
  return similarity * multiplier;
}

function loadRatings() {
  try {
    ratings = JSON.parse(fs.readFileSync('ratings.json', 'utf-8'));
  } catch {
    ratings = {};
  }
}

function saveRatings() {
  fs.writeFileSync('ratings.json', JSON.stringify(ratings, null, 2));
}

function loadMarkov() {
  const text = fs.readFileSync(path.join(__dirname, 'corpus/training.txt'), 'utf-8');
  const tokens = text.split(/\s+/);
  for (let i = 0; i < tokens.length - 2; i++) {
    const key = tokens[i] + ' ' + tokens[i + 1];
    if (!markov[key]) markov[key] = [];
    markov[key].push(tokens[i + 2]);
  }
}

function generateMarkov(seed = null, maxLen = 25) {
  const keys = Object.keys(markov);
  let key = seed && markov[seed] ? seed : keys[Math.floor(Math.random() * keys.length)];
  const result = key.split(' ');
  for (let i = 0; i < maxLen; i++) {
    const nextTokens = markov[key];
    if (!nextTokens) break;
    const word = nextTokens[Math.floor(Math.random() * nextTokens.length)];
    result.push(word);
    key = result[result.length - 2] + ' ' + result[result.length - 1];
  }
  return result.join(' ');
}

async function buildEmbeddingIndex() {
  const raw = JSON.parse(fs.readFileSync('embeddings.json', 'utf-8'));
  texts = raw.map(r => r.text);
  const vectors = raw.map(r => r.vector);
  embeddingTensor = tf.tensor2d(vectors);
  const norms = vectors.map(v => Math.hypot(...v));
  embeddingNorms = tf.tensor1d(norms);
}

async function findSimilar(query) {
  const emb = await model.embed([query]);
  const qVec = emb.arraySync()[0];
  emb.dispose();

  const qTensor = tf.tensor1d(qVec);
  const qNorm = qTensor.norm();

  let sims = embeddingTensor.matMul(qTensor.reshape([-1, 1]))
    .div(embeddingNorms.mul(qNorm))
    .squeeze();
  const simsArr = sims.arraySync();
  sims.dispose();
  qTensor.dispose();
  qNorm.dispose();

  // Вычисляем вес с учетом рейтинга (даже если рейтинг равен 1)
  const weighted = simsArr.map((sim, i) => {
    const currentRating = ratings[texts[i]] || 0;
    return { idx: i, weight: cosineWeights(sim, currentRating), sim };
  });

  if (weighted.length === 0) return null;

  // Сортировка по убыванию веса и выбор top-k вариантов
  weighted.sort((a, b) => b.weight - a.weight);
  const topCandidates = weighted.slice(0, argv.topk);
  const choice = topCandidates[Math.floor(Math.random() * topCandidates.length)];

  return choice.sim >= argv.threshold ? texts[choice.idx] : null;
}

function updateMarkovChainWithInput(text) {
  const tokens = text.split(/\s+/);
  for (let i = 0; i < tokens.length - 2; i++) {
    const key = tokens[i] + ' ' + tokens[i + 1];
    if (!markov[key]) markov[key] = [];
    markov[key].push(tokens[i + 2]);
  }
}

function updateLearning(userInput) {
  updateMarkovChainWithInput(userInput);
  fs.appendFileSync(path.join(__dirname, 'corpus/training.txt'), `${userInput}\n`);
}

async function main() {
  console.log('🔄 Загружаем модель USE и эмбеддинги...');
  await tf.ready();
  model = await use.load();
  await buildEmbeddingIndex();
  loadMarkov();
  loadRatings();

  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  console.log("AI> Привет! Пишите 'оценка 1-5' для оценки ответа.");

  rl.on('line', async (line) => {
    const input = line.trim();
    saveToHistory('User', input);

    // Обработка команды оценки
    if (/^оценка\s+[1-5]$/.test(input)) {
      const rating = parseInt(input.split(' ')[1]);
      if (pendingResponses.length > 0) {
        // Берем самый последний (последний добавленный) ответ для оценки
        const responseToRate = pendingResponses.pop();
        ratings[responseToRate] = rating;
        saveRatings();
        console.log(`AI> Спасибо, оценка сохранена!`);
        saveToHistory('AI', `Оценка: ${rating}`);
      } else {
        console.log("AI> Нет ответа для оценки.");
      }
      return;
    }

    // Поиск похожего ответа по эмбеддингам
    let response = await findSimilar(input);
    if (!response) {
      const tokens = input.split(/\s+/);
      const seed = tokens.length >= 2 ? tokens.slice(0, 2).join(' ') : null;
      response = generateMarkov(seed);
    }
    response = selectSentences(response);

    // Добавляем сгенерированный ответ в очередь для возможности оценки
    pendingResponses.push(response);
    console.log(`AI> ${response}`);
    saveToHistory('AI', response);

    updateLearning(input);
  });
}

main();